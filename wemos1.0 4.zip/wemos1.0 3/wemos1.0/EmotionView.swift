//
//  EmotionView.swift
//  wemos1.0
//
//  Created by Sara Varone on 17/05/24.
//
import Foundation
import Accelerate

class EmotionView: ObservableObject {
    let freq=FreqView()
    func fetchMatrix() -> [[Double]] {
        guard let filePath = Bundle.main.path(forResource: "matrix", ofType: "csv") else {
            fatalError("File CSV non trovato")
        }
        
        do {
            var csvContent = try String(contentsOfFile: filePath, encoding: .utf8)
            
            // Rimuovi l'ultima riga vuota, se presente
            csvContent = csvContent.trimmingCharacters(in: .whitespacesAndNewlines)
            
            let rows = csvContent.components(separatedBy: "\n")
            var matrix: [[String]] = []
            
            for row in rows {
                let columns = row.components(separatedBy: ",")
                matrix.append(columns)
            }
            
            let numericMatrix: [[Double]] = matrix.map { row in
                row.compactMap { Double($0) }
            }
            return numericMatrix
        } catch {
            fatalError("Errore durante la lettura del file CSV: \(error)")
        }
    }
    func fetchMatrixLDA() -> [[Double]] {
        guard let filePath = Bundle.main.path(forResource: "LDA", ofType: "csv") else {
            fatalError("File CSV non trovato")
        }
        
        do {
            var csvContent = try String(contentsOfFile: filePath, encoding: .utf8)
            
            // Rimuovi l'ultima riga vuota, se presente
            csvContent = csvContent.trimmingCharacters(in: .whitespacesAndNewlines)
            
            let rows = csvContent.components(separatedBy: "\n")
            var matrix: [[String]] = []
            
            for row in rows {
                let columns = row.components(separatedBy: ",")
                matrix.append(columns)
            }
            
            let LDAmatrix: [[Double]] = matrix.map { row in
                row.compactMap { Double($0) }
            }
            return LDAmatrix
        } catch {
            fatalError("Errore durante la lettura del file CSV: \(error)")
        }
    }
    func getEmotions()-> [String: Bool]{
        let M = self.fetchMatrix()
        let LDAmatrix=self.fetchMatrixLDA()
        let (mean_st, sdnn_st, rmssd_st, pnn50_st, LFn_st, HFn_st, LF_HF_st) = freq.fetchAndCalculateFreqIndices()
        
        let indices=[mean_st,sdnn_st,rmssd_st,pnn50_st,LFn_st,HFn_st,LF_HF_st]
        var indicesLDA=[Double](repeating: 0.0, count: 7)
        let LDAmatrixArray = LDAmatrix.flatMap { $0 }
               
     // Moltiplica il vettore indices per la matrice LDAmatrix, otteniamo un vettore 1x4
    vDSP_mmulD(indices, 1, LDAmatrixArray, 1, &indicesLDA, 1, 1, vDSP_Length(LDAmatrix.count), vDSP_Length(LDAmatrix.count))
        
        
        var dist: [Double] = Array(repeating: 0.0, count: M.count) // Inizializza l'array dist con elementi a 0
        
        for i in 0..<M.count {
            dist[i] = sqrt(pow((indicesLDA[0] - M[i][0]), 2)+pow((indicesLDA[1]-M[i][1]),2)+pow((indicesLDA[2]-M[i][2]),2)+pow((indicesLDA[3]-M[i][3]),2)) // Utilizza pow per elevare al quadrato, usa [0],[1] ecc per accedere alla prima,seconda,ecc colonna di ogni riga
        }
        guard let minIndex = dist.indices.min(by: { dist[$0] < dist[$1] }) else {
            print("Errore: array vuoto")
            return[:]
        }
        var emotions: [String: Bool] = [
                "happiness": false,
                "fear": false,
                "anger": false,
                "sadness": false,
                "calm": false
            ]
        if (minIndex>0 && minIndex<=91){
            emotions["happiness"]=true
        } else if (minIndex>=92 && minIndex<=183){
            emotions["fear"]=true
        } else if (minIndex>=184 && minIndex<=275){
            emotions["anger"]=true
        }else if(minIndex>=276 && minIndex<=367){
            emotions["sadness"]=true
        }else if(minIndex>=368 && minIndex<=459){
            emotions["calm"]=true
        } //else {
          //  emotions["calm"]=true
     //   }
        return emotions
    }
}

