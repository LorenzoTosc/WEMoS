//
//  SadnessView.swift
//  Prova1
//
//  Created by Sara Varone on 30/04/24.
//

import SwiftUI
import PhotosUI
import Photos




struct SadnessView: View {
    @State private var randomImage: UIImage?
    @State private var accessDenied=false
    
    var body: some View {
        ZStack{
            Color.blue.edgesIgnoringSafeArea(.all) // Imposta lo sfondo blu
                .blur(radius:70)
            VStack{
                HStack{
                    Image(systemName: "cloud.drizzle.fill")
                        .foregroundColor(.white)
                        .dynamicTypeSize(.xxxLarge)
                    Text("You seem sad")
                        .font(.title)
                        .underline()
                        .bold()
                        .foregroundColor(.white)
                        .padding()
                        .alignmentGuide(.top){_ in UIScreen.main.bounds.size.height/10}
                    Image(systemName: "cloud.drizzle.fill")
                        .foregroundColor(.white)
                        .dynamicTypeSize(.xxxLarge)
                }
                //Spacer()
                Button(action:{
                    // Qui carichiamo una foto casuale dall'album dei preferiti
                    loadRandomImageFromFavorites()
                }){
                    
                    Text("Have a look at this beautiful memory!")
                        .font(.headline)
                        .bold()
                        .foregroundColor(.gray)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                }
                .padding()
                if let image = randomImage {
                    ZStack{
                        Color.cyan.frame(width:360, height:360)
                            .blur(radius:20)
                        VStack{
                            //Spacer()
                            Image(uiImage: image)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 300, height: 300)
                                .padding()
                           // Spacer()
                        }
                    }
                   
                }
                ZStack{
                    Color.white.frame(width:380,height: 80)
                        .blur(radius:5)
                    VStack{
                        
                        Text("Warning\nIf you find yourself having trouble dealing with your emotions don't hesitate asking for help").italic().multilineTextAlignment(.center)
                            .font(.subheadline)
                            .padding()
                            .cornerRadius(10)
                    }
                }
            }
            .edgesIgnoringSafeArea(.all)
            .alert(isPresented: $accessDenied) {
                Alert(title: Text("Accesso alle foto negato"), message: Text("Per utilizzare questa funzionalità, l'app ha bisogno dell'accesso alle tue foto."), primaryButton: .default(Text("OK")), secondaryButton: .cancel())
            }
       
        }
    }
                
    func loadRandomImageFromFavorites() {
                    let fetchOptions = PHFetchOptions()
                    fetchOptions.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
                    let fetchResult = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: .smartAlbumFavorites, options: nil)
                    if let album = fetchResult.firstObject {
                        let assets = PHAsset.fetchAssets(in: album, options: fetchOptions)
                        if assets.count > 0 {
                            let randomIndex = Int.random(in: 0..<assets.count)
                            let asset = assets.object(at: randomIndex)
                            let options = PHImageRequestOptions()
                            options.isSynchronous = true
                            options.deliveryMode = .highQualityFormat
                            PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 300, height: 300), contentMode: .aspectFit, options: options) { image, _ in
                                DispatchQueue.main.async {
                                    self.randomImage = image
                                }
                            }
                        }
                    }
                }
            }
        
    





#Preview {
    SadnessView()
}
