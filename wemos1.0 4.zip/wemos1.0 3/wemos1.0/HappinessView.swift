//
//  HappinessView.swift
//  wemos1.0
//
//  Created by Sara Varone on 04/05/24.
//

import SwiftUI
import AVFoundation

struct HappinessView: View {
    @State private var isCameraAuthorized = false
    @State private var isShowingImagePicker = false
    @State private var capturedImage: UIImage?
    
    var body: some View {
        ZStack{
            Color.yellow.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                .blur(radius:60)
        VStack {
            HStack{
                Image(systemName: "face.smiling")
                    .foregroundColor(.white)
                    .dynamicTypeSize(.xxxLarge)
                Text("You seem happy!")
                    .font(.title)
                    .foregroundColor(.white)
                    .bold()
                    .underline()
                    .alignmentGuide(.top){_ in UIScreen.main.bounds.size.height/10}
                Image(systemName: "face.smiling")
                    .foregroundColor(.white)
                    .dynamicTypeSize(.xxxLarge)
            }
            Text("If you'd like, take a photo to remember this moment as a happy moment, and save it in your favorites album!")
                .multilineTextAlignment(.center)
                .padding()
                .font(.headline)
            Button(action: {
                if self.isCameraAuthorized {
                    self.isShowingImagePicker = true
                } else {
                    print("Camera access is required.")
                }
            }) {
                Text("Capture a Happy Moment!")
                    .font(.headline)
                    .bold()
                    .foregroundColor(.gray)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
            }
            Spacer()
            HStack{
               Image(systemName: "exclamationmark.bubble.fill")
                    .foregroundColor(.white)
                    .dynamicTypeSize(.xxxLarge)
                
              Text("Remember to always appreciate these moments!")
                    .font(.headline)
                    .bold()
                    .padding()
                    .multilineTextAlignment(.center)
            }
            //.padding()
            .sheet(isPresented: $isShowingImagePicker) {
                if self.isCameraAuthorized {
                    ImagePickerView(capturedImage: self.$capturedImage)
                } else {
                    Text("Camera access is required.")
                }
            }
            .onAppear {
                self.checkCameraAuthorization()
            }
            .alert(isPresented: .constant(!self.isCameraAuthorized)) {
                Alert(
                    title: Text("Camera Access Denied"),
                    message: Text("To use this feature, the app needs access to the camera."),
                    primaryButton: .default(Text("OK")),
                    secondaryButton: .cancel()
                )
            }
        }
    }
}
    
    func checkCameraAuthorization() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        self.isCameraAuthorized = status == .authorized
    }
}
#Preview{
    
        HappinessView()
    
    }

