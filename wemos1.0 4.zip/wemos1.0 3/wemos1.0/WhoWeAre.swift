//
//  WhoWeAre.swift
//  wemos1.0
//
//  Created by Sara Varone on 02/05/24.
//

import SwiftUI
//import SwiftUIX
struct WhoWeAre: View {
    var body: some View {
        VStack {
            Image("12B0A139-2AAE-4E34-A223-7181B24176B7")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200, height: 200)
                .padding(.bottom, 20) // Aggiungi spazio sotto l'immagine
            
            Text("About Us")
                .font(.title)
                .bold()
                .foregroundColor(.black); // Usa un colore blu notte definito nel file di asset
            
            Text("We are Sara, Maria, Lorenzo, Luca, and we are in the third year of the Bachelor's degree program in Biomedical Engineering at Politecnico di Milano. We are pleased to introduce you to WEMoS.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                .padding(.horizontal, 20) // Aggiungi spazio ai lati del testo
            
            HStack(spacing: 10) { // Riduci lo spazio tra le immagini
                Image("890C6A43-57C2-4FFE-A23B-2FAD9BDFA3DB_4_5005_c")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 150, height: 150)
                
                Image("B38BBAAD-F656-48B0-953D-8A9916AC0028_4_5005_c")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 150, height: 150)
            }
            .padding(.top, 10) // Aggiungi spazio sopra le immagini
        }
        .padding()
    }
}

struct WhoWeAre_Previews: PreviewProvider {
    static var previews: some View {
        WhoWeAre()
    }
}
