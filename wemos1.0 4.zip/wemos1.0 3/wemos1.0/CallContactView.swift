//
//  CallContactView.swift
//  wemos1.0
//
//  Created by Sara Varone on 16/05/24.
//
import SwiftUI
import Contacts

struct CallContactView: View {
    @State private var favoriteContacts: [CNContact] = []
    
    var body: some View {
        VStack {
            if favoriteContacts.isEmpty {
                Text("Loading favorite contacts...")
                    .padding()
            } else {
                List(favoriteContacts, id: \.identifier) { contact in
                    Button(action: {
                        self.callContact(contact)
                    }) {
                        Text("\(contact.givenName) \(contact.familyName)")
                    }
                }
            }
        }
        .onAppear {
            fetchFavoriteContacts()
        }
        .navigationTitle("Call whoever you'd like to have a chat with from your contacts")
    }
    
    private func fetchFavoriteContacts() {
        let contactStore = CNContactStore()
        
        var favoriteContacts = [CNContact]()
        
        // Recupera i contatti preferiti
        let keys = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey, CNContactImageDataKey, CNContactThumbnailImageDataKey] as [CNKeyDescriptor]
        let fetchRequest = CNContactFetchRequest(keysToFetch: keys)
        fetchRequest.predicate = CNContact.predicateForContactsInContainer(withIdentifier: contactStore.defaultContainerIdentifier())
        
        do {
            try contactStore.enumerateContacts(with: fetchRequest, usingBlock: { (contact, _) in
                if contact.isKeyAvailable(CNContactPhoneNumbersKey) {
                    favoriteContacts.append(contact)
                }
            })
            self.favoriteContacts = favoriteContacts
        } catch {
            print("Error fetching favorite contacts: \(error)")
        }
    }
    
    private func callContact(_ contact: CNContact) {
        guard let phoneNumber = contact.phoneNumbers.first?.value.stringValue,
              let url = URL(string: "tel://\(phoneNumber)"),
              UIApplication.shared.canOpenURL(url) else {
            print("Unable to make call to contact")
            return
        }
        
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}

struct CallContactView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Text("This is a preview of a larger view")
            CallContactView()
                .padding()
        }
    }
}
