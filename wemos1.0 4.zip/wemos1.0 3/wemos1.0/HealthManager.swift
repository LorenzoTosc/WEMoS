//
//  HealthManager.swift
//  Prova1
//
//  Created by Sara Varone on 04/04/24.
//
import Foundation
import HealthKit

class HealthManager: ObservableObject {
    let healthStore = HKHealthStore()
    let heartbeatType = HKSeriesType.heartbeat()
    let heartRateVariabilityType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
    var lastHeartbeatTimestamps: [TimeInterval]=[] // Dichiarazione della variabile di istanza
    
    var timestamps: [TimeInterval] = [] // Dichiarazione del vettore di timestamp
    
    func requestHealthDataAuthorization() { //funzione per richiedere l'autorizzazione, questa è ok
        // Verifica se HealthKit è disponibile sul dispositivo
        guard HKHealthStore.isHealthDataAvailable() else {
            print("HealthKit non è disponibile su questo dispositivo.")
            return
        }
        
        // Richiedi l'autorizzazione per accedere ai dati relativi al battito cardiaco e alla variabilità del battito cardiaco -> questo perchè heart beat è legato ad HRV
        let typesToRead: Set<HKObjectType> = [heartbeatType, heartRateVariabilityType]
        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { (success, error) in
            if let error = error {
                print("Errore durante la richiesta di autorizzazione: \(error.localizedDescription)")
                return
            }
            
            if success {
                print("Autorizzazione ottenuta con successo per accedere ai dati relativi al battito cardiaco e alla variabilità del battito cardiaco.")
            } else {
                print("L'utente ha negato l'autorizzazione ad accedere ai dati relativi al battito cardiaco e alla variabilità del battito cardiaco.")
            }
        }
    }
    //Funzione per estrarre gli istanti temporali di ogni battito (che verrà poi passata in input alla funzione per calcolare gli indici, per ottenere il vettore RR. In sostanza, questa funzione esegue due query su HealthKit: una per ottenere i campioni dei battiti cardiaci nell'intervallo di tempo specificato e l'altra per recuperare i dati specifici relativi a ciascun campione di battito cardiaco.
    
    
    func requestHeartbeatData() -> [TimeInterval] {
        var timestamps = [TimeInterval]()
        
        let startDate = Calendar.current.date(byAdding: .hour, value: -5, to: Date())!
        let endDate = Calendar.current.date(byAdding: .hour, value: -1, to: Date())!
        //let endDate = Date()
        
        let timePredicate = HKQuery.predicateForSamples(withStart: startDate, end: endDate, options: .strictStartDate)
        
        let seriesQuery = HKSampleQuery(sampleType: heartbeatType,
                                        predicate: timePredicate,
                                        limit: HKObjectQueryNoLimit,
                                        sortDescriptors: nil) { [self] (query, samples, error) in
            guard let samples = samples as? [HKHeartbeatSeriesSample] else {
                if let error = error {
                    print("Error fetching heartbeat samples: \(error.localizedDescription)")
                }
                return
            }
            
            for sample in samples {
                let heartbeatQuery = HKHeartbeatSeriesQuery(heartbeatSeries: sample) { (query, data, done, _, error) in
                    if let error = error {
                        print("Error fetching heartbeat samples: \(error.localizedDescription)")
                        return
                    }
                    
                    guard data > 0 else {
                        return
                    }
                    
                    timestamps.append(data * 1000)
                    
                    if done && samples.last == sample {
                        // Segnala che i dati sono stati completamente elaborati
                        DispatchQueue.main.async {
                            print("Dati completamente elaborati")
                            // Puoi fare qualcosa qui se necessario, ma non è obbligatorio
                        }
                    }
                }
                
                self.healthStore.execute(heartbeatQuery)
            }
        }
        
        self.healthStore.execute(seriesQuery)
        
        // Attendere finché i dati non sono completamente elaborati
        while timestamps.isEmpty {
            // Attendere un po' di tempo prima di controllare di nuovo
            // Puoi regolare il tempo di attesa in base alle tue esigenze
            usleep(10000) // Attendere 10 millisecondi
        }
        
        return timestamps
    }
}
