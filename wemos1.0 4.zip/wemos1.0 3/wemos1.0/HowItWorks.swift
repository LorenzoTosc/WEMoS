//
//  HowItWorks.swift
//  wemos1.0
//
//  Created by Sara Varone on 02/05/24.
//
import SwiftUI

struct HowItWorks: View {
    let customFont: Font = .system(size: 16, weight: .regular)

    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 20) {
                Text("Welcome to WEMoS!")
                    .font(.title)
                    .bold()
                    .foregroundColor(.green)
                    .font(customFont)

                Text("What's WEMoS?")
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .font(customFont)

                Text("WEMoS is a system for smartwatch users designed to recognize emotions and provide personalized feedback, focusing on emotional wellness.")
                    .multilineTextAlignment(.center)
                    .font(customFont)
                    .padding()

                VStack(alignment: .leading, spacing: 10) {
                    Text("Here's a little guide on how this works")
                        .font(.headline)
                        .font(customFont)

                    VStack(alignment: .leading, spacing: 8) {
                        Text("• Wear your Apple Watch.")
                        Text("• Let it measure your HRV (Heart Rate Variability).")
                        Text("• Identify the emotion you are feeling.")
                    }
                    .font(.subheadline)
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.yellow)
                    .cornerRadius(10)
                }

                ZStack {
                    Color.mint
                        .frame(width: 367, height: 300)
                        .cornerRadius(10) // Applica il corner radius direttamente al colore di sfondo

                    VStack {
                        Text("Here are some tips:")
                            .font(.headline)
                            .font(customFont)

                        Text("1. Remember to give access to health data and photos, this will be necessary for us to help you!\n\n2. Make sure your photo album Favorites is full of happy moments \n \n 3. If you enable atrial fibrillation history on your watch, this will allow us to have more measurements to better analyze your emotional state!")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .font(customFont)
                            .padding()
                    }
                }
                .padding()
            }
            .padding()
        }
    }
}

struct HowItWorks_Previews: PreviewProvider {
    static var previews: some View {
        HowItWorks()
    }
}
