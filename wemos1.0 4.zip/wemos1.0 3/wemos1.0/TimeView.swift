//
//  TimeView.swift
//  Prova1
//
//  Created by Maria Stangalini on 16/04/24.
//

import Foundation
import UIKit

class TimeView {
    let healthManager=HealthManager()
    //var timestamps: [TimeInterval] = []

    // Funzione per recuperare i timestamp dei battiti cardiaci e quindi calcolare gli indici
    func fetchAndCalculateTimeIndices() {
        let (timestamps)=healthManager.requestHeartbeatData()
        let (RR_res, _,_,_,_) = self.calculateTimeIndices(with: timestamps)
        print("Timestamps: \(timestamps))")
        
        print("RR_res: \(RR_res)", terminator: "\n\n")
    }
    func calculateTimeIndices(with time: [TimeInterval]) -> ( [TimeInterval], Double, Double, Double, Double) {
        // Calcola gli indici usando i timestamp dei battiti cardiaci
        var RR = [TimeInterval]()

                for i in 0..<(time.count - 1) {
                    let interval = TimeInterval(time[i + 1] - time[i])
                    if interval <= 1200 {
                        RR.append(interval)
                    }
                }
     
        
        let N_RR = RR.count
        
        // Calcolo di timeInSeconds
        var timeInSeconds = [TimeInterval](repeating: 0.0, count: N_RR)
        timeInSeconds[0] = RR[0] / 1000.0 // Dividi per 1000 per ottenere i valori di tempo in secondi, non in millisecondi
        for i in 1..<N_RR {
            timeInSeconds[i] = timeInSeconds[i - 1] + RR[i] / 1000.0
        }
        
        // Calcolo di time_res
        let fs = 4 // Hz
        let Ts = 1.0 / Double(fs) // [s]
        
        var time_res = [TimeInterval]()
        var i = 0
        time_res.append(timeInSeconds[0])
        while time_res[i] < timeInSeconds[N_RR - 1] {
            time_res.append(time_res[i] + Ts)
            i += 1
        }
        
        let N = time_res.count // Lunghezza di time_res
        // Calcolo di RR_res
        var RR_res = [TimeInterval](repeating: 0.0, count: N) // Inizializza RR_res con la stessa lunghezza di time_res
        var j = 1
        var m = 0.0
        var q = 0.0
        RR_res[0]=RR[0]
        for s in 1..<N_RR {
            m = (RR[s] - RR[s - 1]) / (timeInSeconds[s] - timeInSeconds[s - 1])
            q = RR[s - 1] - m * timeInSeconds[s - 1]
            
            while j < N && time_res[j] < timeInSeconds[s] {
                RR_res[j] = m * time_res[j] + q
                j += 1
            }
        }
      
        RR_res[N - 1] = RR[N_RR - 1]
        
        // Calcolo della media, deviazione standard, RMSSD e PNN50
        let meanRR = RR.reduce(0.0, +) / Double(N_RR)
        let sdnn = sqrt(RR.map { pow($0 - meanRR, 2) }.reduce(0.0, +) / Double(N_RR - 1))
        let rmssd = sqrt(zip(RR.dropFirst(), RR).map { pow($0 - $1, 2) }.reduce(0.0, +) / Double(N_RR - 1))
        //let pnn50 = Double(RR.dropLast().enumerated().filter { abs($0.element - RR[$0.offset + 1]) > 50 }.count) / Double(N_RR - 1)
        var cont=0
        for i in 0..<(N_RR-1){
            if(abs(RR[i+1]-RR[i])>50){
                cont=cont+1
            }
        }
        let pnn50=Double(cont)/Double(N_RR-1)
        
        
        // Stampa dei risultati
        print("RR: \(RR)", terminator: "\n\n")
        print("Mean: \(meanRR)", terminator: "\n\n")
        print("SDNN: \(sdnn)", terminator: "\n\n")
        print("RMSSD: \(rmssd)", terminator: "\n\n")
        print("PNN50: \(pnn50)", terminator: "\n\n")
    
        return (RR_res, meanRR,sdnn,rmssd,pnn50)
    }
}
