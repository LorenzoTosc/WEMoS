//
//  HomeView.swift
//  wemos1.0
//
//  Created by Sara Varone on 17/05/24.
//
import SwiftUI
import Photos
import PhotosUI
import AVFoundation
import UIKit
import HealthKit
import HealthKitUI
import Contacts

struct HomeView: View {
    @ObservedObject var healthManager = HealthManager()
    @State private var lastHeartbeatTimestamps = [TimeInterval]()
    @State private var isCameraAuthorized = false
    @State private var capturedImage: UIImage?
    @State private var isShowingImagePicker = false
    
    @State private var isAuthorized = false
    let healthStore = HKHealthStore()
    let heartbeatType = HKSeriesType.heartbeat()
    let heartRateVariabilityType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
    let contactStore=CNContactStore()
    
    var body: some View {
        NavigationView{
          //  Color.green.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).opacity(0.1)
            VStack(alignment: .center) {
                
                Text("Home")
                    .font(.title)
                    .bold()
                    .foregroundColor(.black)
                Spacer()
                HStack{
                    ZStack{
                        
                        Color.green.frame(width:150, height:50)
                        NavigationLink(destination: HowItWorks()){
                            Text("What's WEMoS")
                                .font(.headline)
                                .padding()
                                .cornerRadius(10)
                                .foregroundColor(.white)
                                .underline()
                        }
                    }
                    ZStack{
                        Color.green.frame(width:150, height:50)
                        NavigationLink(destination:WhoWeAre()){
                            Text("About us")
                                .font(.headline)
                                .padding()
                                .foregroundColor(.white)
                                .underline()
                        }
                    }
                }
                
                Spacer()
                NavigationLink(destination: FinestreView()){
                    Text("Know your emotions")
                        .font(.headline)
                        .padding()
                        .cornerRadius(10)
                }
                Spacer()
            }
            
            
            .onAppear {
                
                healthManager.requestHealthDataAuthorization()
                // Controlla lo stato dell'autorizzazione alla libreria foto
                requestPhotoLibraryAccess()
                checkPhotoLibraryAuthorizationStatus()
                if self.isCameraAuthorized {
                    self.isShowingImagePicker = true
                } else {
                    self.requestCameraPermission()
                }
                contactStore.requestAccess(for: .contacts) { (granted, error) in
                    guard granted else {
                        print("Accesso ai contatti non autorizzato")
                        return
                    }
                    let timeView=TimeView()
                     timeView.fetchAndCalculateTimeIndices()
                    
                      let freqView=FreqView()
                     freqView.fetchAndCalculateFreqIndices()
                    
                    let emotionView=EmotionView()
                    let(emotions)=emotionView.getEmotions()
                        print("\(emotions)")
                }
            }
        }
    }
    func checkPhotoLibraryAuthorizationStatus() {
        let status = PHPhotoLibrary.authorizationStatus()
        if status == .authorized {
            // L'accesso alla libreria foto è già stato autorizzato
            isAuthorized = true
        }
    }
    
    
    func requestPhotoLibraryAccess() {
        PHPhotoLibrary.requestAuthorization { status in
            DispatchQueue.main.async {
                if status == .authorized {
                    // L'utente ha autorizzato l'accesso alla libreria foto
                    self.isAuthorized = true
                } else {
                    // L'utente ha negato l'accesso o è impossibilitato ad autorizzarlo
                    // Puoi gestire questo caso come preferisci
                }
            }
        }
    }
    func checkCameraAuthorization() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        self.isCameraAuthorized = status == .authorized
    }
    
    func requestCameraPermission() {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            DispatchQueue.main.async {
                self.isCameraAuthorized = granted
            }
        }
    }
    
}
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}





/*import SwiftUI
import Photos
import PhotosUI
import AVFoundation
import UIKit
import HealthKit
import HealthKitUI
import Contacts

struct HomeView: View {
    @ObservedObject var healthManager = HealthManager()
    @State private var lastHeartbeatTimestamps = [TimeInterval]()
    @State private var isCameraAuthorized = false
    @State private var capturedImage: UIImage?
    @State private var isShowingImagePicker = false
    
    @State private var isAuthorized = false
    let healthStore = HKHealthStore()
    let heartbeatType = HKSeriesType.heartbeat()
    let heartRateVariabilityType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
    let contactStore=CNContactStore()
    
    var body: some View {
        NavigationView{
            Color.green.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).opacity(0.1)
            VStack(alignment: .center) {
               
                Text("Home")
                    .font(.title)
                    .bold()
                    .foregroundColor(.black)
                Spacer()
                HStack{
                    ZStack{
                        
                        Color.green.frame(width:150, height:50)
                        NavigationLink(destination: HowItWorks()){
                            Text("What's WEMoS")
                                .font(.headline)
                                .padding()
                                .cornerRadius(10)
                                .foregroundColor(.white)
                                .underline()
                        }
                    }
                    ZStack{
                        Color.green.frame(width:150, height:50)
                        NavigationLink(destination:WhoWeAre()){
                            Text("About us")
                                .font(.headline)
                                .padding()
                                .foregroundColor(.white)
                                .underline()
                        }
                    }
                }
                
                Spacer()
                NavigationLink(destination: FinestreView()){
                    Text("Know your emotions")
                        .font(.headline)
                        .padding()
                        .cornerRadius(10)
                }
                Spacer()
            }
            
            
            .onAppear {
                
                healthManager.requestHealthDataAuthorization()
                // Controlla lo stato dell'autorizzazione alla libreria foto
                requestPhotoLibraryAccess()
                checkPhotoLibraryAuthorizationStatus()
                if self.isCameraAuthorized {
                    self.isShowingImagePicker = true
                } else {
                    self.requestCameraPermission()
                }
                contactStore.requestAccess(for: .contacts) { (granted, error) in
                    guard granted else {
                        print("Accesso ai contatti non autorizzato")
                        return
                    }
                    let timeView=TimeView()
                     timeView.fetchAndCalculateTimeIndices()
                    
                      let freqView=FreqView()
                     freqView.fetchAndCalculateFreqIndices()
                    
                    let emotionView=EmotionView()
                    let(emotions)=emotionView.getEmotions()
                        print("\(emotions)")
                }
            }
        }
    }
    func checkPhotoLibraryAuthorizationStatus() {
        let status = PHPhotoLibrary.authorizationStatus()
        if status == .authorized {
            // L'accesso alla libreria foto è già stato autorizzato
            isAuthorized = true
        }
    }
    
    
    func requestPhotoLibraryAccess() {
        PHPhotoLibrary.requestAuthorization { status in
            DispatchQueue.main.async {
                if status == .authorized {
                    // L'utente ha autorizzato l'accesso alla libreria foto
                    self.isAuthorized = true
                } else {
                    // L'utente ha negato l'accesso o è impossibilitato ad autorizzarlo
                    // Puoi gestire questo caso come preferisci
                }
            }
        }
    }
    func checkCameraAuthorization() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        self.isCameraAuthorized = status == .authorized
    }
    
    func requestCameraPermission() {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            DispatchQueue.main.async {
                self.isCameraAuthorized = granted
            }
        }
    }
    
}
struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}*/
