//
//  SecondScreenView.swift
//  wemos1.0
//
//  Created by Sara Varone on 17/05/24.
//
import SwiftUI
import HealthKit
import AVFoundation
import _AVKit_SwiftUI

struct SecondScreenView: View {
    let emotion = EmotionView()
    @State private var currentEmotion: String?
    @State private var isCalm = true
    @State private var emotions = [String: Bool]() // Dichiarato come @State
    let healthStore = HKHealthStore()
    
    var body: some View {
        VStack {
            if isCalm {
                Color.orange.opacity(0.5)
                    .edgesIgnoringSafeArea(.all)
                    .blur(radius: 60)
                    .overlay(
                        VStack {
                            VStack {
                                HStack {
                                    Image(systemName: "leaf")
                                        .foregroundColor(.white)
                                        .dynamicTypeSize(.xxxLarge)
                                    Text("Everything is calm here!")
                                        .font(.title).bold().underline()
                                        .foregroundStyle(.white)
                                    Image(systemName: "leaf")
                                        .foregroundColor(.white)
                                        .dynamicTypeSize(.xxxLarge)
                                }
                                .padding(.top, 70) // Spazio tra il bordo superiore e il testo
                                Text("Keep it up!\n")
                                    .font(.headline)
                                    .bold()
                                    .foregroundStyle(.white)
                                    .padding()
                                    .multilineTextAlignment(.center)
                                Spacer().frame(height: 50) // Spazio tra il testo e il video
                                
                                if let videoURL = Bundle.main.url(forResource: "calm", withExtension: "mov") {
                                    VideoPlayer(player: AVPlayer(url: videoURL))
                                        .frame(width: 240, height: 180)
                                } else {
                                    Text("Video non trovato")
                                        .foregroundColor(.white)
                                        .frame(width: 200, height: 100)
                                        .background(Color.red)
                                }
                            }
                            Spacer() // Spinge il contenuto verso l'alto
                        }
                            .padding(.top, 30), // Aggiungi padding per spostare l'intero blocco verso l'alto
                        alignment: .top // Allinea il contenuto in alto
                    )
            } else {
                VStack {
                    if emotions["happiness", default: false] {
                        HappinessView()
                    } else if emotions["fear", default: false] {
                        FearView()
                    } else if emotions["anger", default: false] {
                        AngerView()
                    } else if emotions["sadness", default: false] {
                        SadnessView()
                    }
                }
            }
        }
        .onAppear {
                    self.getEmotions()
                    }

                }
            
    func getEmotions() {
            self.emotions = emotion.getEmotions()
            if self.emotions["calm", default: false]{
                self.isCalm=true
            }else{
                self.isCalm=false
            }
        }
    }
        
        
        
        
      /*  .onAppear {
             // Abilita lo sfondo delivery per le misurazioni di HRV
             let heartRateVariabilityType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
             self.healthStore.enableBackgroundDelivery(for: heartRateVariabilityType, frequency: .immediate) { success, error in
             guard success else {
             if let error = error {
             print("Errore durante l'abilitazione dello sfondo delivery per HRV: \(error.localizedDescription)")
             }
             return
             }
             print("Lo sfondo delivery per HRV è stato abilitato con successo")
             }
             
             // Richiama getEmotions() ogni volta che una misura di HRV viene aggiunta
             NotificationCenter.default.addObserver(forName: .init("com.apple.health.heartbeat.query.didUpdate"), object: nil, queue: nil) { notification in
             self.getEmotions()
             self.sendNotification()
             }
             
             
             }
             }
             
             func getEmotions() {
             self.emotions = emotion.getEmotions()
             self.isCalm = self.emotions["calm", default: false]
             }
             
             func sendNotification() {
             let content = UNMutableNotificationContent()
             content.title = "Scopri che emozione stai provando!"
             content.body = "Una nuova misurazione di HRV è stata registrata."
             content.sound = UNNotificationSound.default
             
             let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
             let request = UNNotificationRequest(identifier: "IdentificatoreNotificaHRV", content: content, trigger: trigger)
             
             UNUserNotificationCenter.current().add(request) { error in
             if let error = error {
             print("Errore nell'invio della notifica: \(error.localizedDescription)")
             } else {
             print("Notifica inviata con successo")
             }
             }
        }
    }*/


#Preview {
    SecondScreenView()
}



/*
import SwiftUI
import HealthKit

struct SecondScreenView: View {
    let emotion = EmotionView()
    @State private var currentEmotion: String?
    @State private var isCalm = true
    @State private var emotions = [String: Bool]() // Dichiarato come @State
    let healthStore = HKHealthStore()
    
    var body: some View {
        VStack {
            if isCalm {
                Text("Qui è tutto calmo")
            } else {
                VStack {
                    if emotions["happiness", default: false] {
                        HappinessView()
                    } else if emotions["fear", default: false] {
                        FearView()
                    } else if emotions["anger", default: false] {
                        AngerView()
                    } else if emotions["sadness", default: false] {
                        SadnessView()
                    }
                }
            }
        }
        .onAppear {
            // Abilita lo sfondo delivery per le misurazioni di HRV
            let heartRateVariabilityType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
            self.healthStore.enableBackgroundDelivery(for: heartRateVariabilityType, frequency: .immediate) { success, error in
                guard success else {
                    if let error = error {
                        print("Errore durante l'abilitazione dello sfondo delivery per HRV: \(error.localizedDescription)")
                    }
                    return
                }
                print("Lo sfondo delivery per HRV è stato abilitato con successo")
            }
            
            // Richiama getEmotions() ogni volta che una misura di HRV viene aggiunta
            NotificationCenter.default.addObserver(forName: .init("com.apple.health.heartbeat.query.didUpdate"), object: nil, queue: nil) { notification in
                self.getEmotions()
            }

        }
    }
    
    func getEmotions() {
        self.emotions = emotion.getEmotions()
        self.isCalm = self.emotions["calm", default: false]
    }
}

#Preview {
    SecondScreenView()
}
*/
