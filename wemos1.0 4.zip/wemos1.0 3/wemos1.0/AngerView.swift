//
//  AngerView.swift
//  wemos1.0
//
//  Created by Sara Varone on 04/05/24.
//

import SwiftUI
import UIKit
import WebKit

struct AngerView: View {
    @State private var isVideoVisible = false
    
    // Funzione per selezionare casualmente uno dei tre URL dei video
    func randomVideoURL() -> URL {
        let videoURLs = [
            "https://youtu.be/wkse4PPxkk4?feature=shared",
            "https://www.youtube.com/watch?v=dnBAU8Co6PA",
            "https://www.youtube.com/watch?v=NnAP1obfiqU"
        ]
        let randomIndex = Int.random(in: 0..<videoURLs.count)
        return URL(string: videoURLs[randomIndex])!
    }
    
    var body: some View {
        ZStack{
            Color.red.edgesIgnoringSafeArea(.all)
                .blur(radius:60)
            VStack{
                HStack{
                    Image(systemName: "flame")
                        .foregroundColor(.white)
                        .font(.system(size: 50))
                    Text("You seem angry")
                        .underline()
                        .bold()
                        .foregroundColor(.white)
                        .font(.title)
                    Image(systemName: "flame")
                        .foregroundColor(.white)
                        .font(.system(size: 50))
                }
                ZStack{
                    Color.white.frame(width: 400, height: 130).blur(radius: 10)
                    Text("In such situations, meditation could really help you. Here is a nice meditation video we recommend you to watch in order to calm down.")
                        .padding()
                        .font(.headline)
                        .multilineTextAlignment(.center)
                }
                Button(action:{
                    self.isVideoVisible = true
                }) {
                    Text("Watch a meditation video!")
                        .font(.headline)
                        .bold()
                        .foregroundColor(.gray)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                }
                if isVideoVisible {
                    YouTubeVideoPlayer(videoURL: randomVideoURL())
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                
            }
        }
    }
}

struct YouTubeVideoPlayer: UIViewRepresentable {
    let videoURL: URL
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        let request = URLRequest(url: videoURL)
        webView.load(request)
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct AngerView_Previews: PreviewProvider {
    static var previews: some View {
        AngerView()
    }
}
