//
//  FearView.swift
//  wemos1.0
//
//  Created by Sara Varone on 04/05/24.
//

import SwiftUI
import AVKit
import Contacts

struct FearView: View {
    let contactStore=CNContactStore()
    @State private var isShowingCallSheet = false
    @State private var selectedContact: CNContact?
    var body: some View {
        ZStack{
            Color.purple.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).blur(radius:60)
            VStack{
                HStack{
                    Image(systemName: "tornado")
                        .foregroundColor(.white)
                        .dynamicTypeSize(.xxxLarge)
                    Text("You seem scared!")
                        .font(.title).bold().underline()
                        .foregroundStyle(.white)
                    Image(systemName: "tornado")
                        .foregroundColor(.white)
                        .dynamicTypeSize(.xxxLarge)
                }
                Text("Try doing this exercise if you need to calm down\n")
                    .font(.headline)
                    .bold()
                    .foregroundStyle(.white)
                    .padding()
                    .multilineTextAlignment(.center)
                
                VideoPlayer(player: AVPlayer(url: Bundle.main.url(forResource: "scared", withExtension: "mov")!))
                    .frame(width:200 , height: 200)
                
                Group{
                    Text("Here's some tips on how to deal with fear!\n")
                        .fontWeight(.bold) // Rendi la prima parte in grassetto
                    +
                    Text("1. Aknowledge it\n2. Try talking about it with someone\n3. Work on what is causing you this emotion: can you make it less scary?")
                }
             
                NavigationLink(destination: CallContactView()) {
                                      Text("Call someone to help you")
                                          .foregroundColor(.white)
                                          .padding()
                                          .background(Color.blue)
                                          .cornerRadius(10)
                                  }
                                  .padding()
                              }
                          }
                        //  .navigationTitle("Fear View")
                      }
            }
                
                  
        

struct FearView_Previews: PreviewProvider {
    static var previews: some View {
        FearView()
    }
}


