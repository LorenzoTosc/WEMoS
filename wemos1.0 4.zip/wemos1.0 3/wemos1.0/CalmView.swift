//
//  CalmView.swift
//  wemos1.0
//
//  Created by Sara Varone on 17/05/24.
//

import SwiftUI

struct CalmView: View {
    var body: some View {
        Text("Qui è tutto calmo")
    }
}

#Preview {
    CalmView()
}
