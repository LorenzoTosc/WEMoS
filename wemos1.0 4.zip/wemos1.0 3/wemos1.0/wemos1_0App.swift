//
//  wemos1_0App.swift
//  wemos1.0
//
//  Created by Sara Varone on 02/05/24.
//

import SwiftUI

@main
struct wemos1_0App: App {
    let healthManager = HealthManager()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(healthManager)
        }
    }
}
