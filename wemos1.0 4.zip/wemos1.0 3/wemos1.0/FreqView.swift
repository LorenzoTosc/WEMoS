//
//  FreqView.swift
//  Prova1
//
//  Created by Maria Stangalini on 16/04/24.
//
import Foundation

class FreqView {
    let timeView = TimeView()
    let healthManager=HealthManager()
   // var timestamps: [TimeInterval] = []
    func fetchAndCalculateFreqIndices() -> ((Double),(Double),(Double),(Double),(Double),(Double),(Double))  {
        // Dichiarazione del vettore di timestamp
        let timestamps = healthManager.requestHeartbeatData()
        
        // Calcolo degli indici temporali
        let (RR_res, mean, sdnn, rmssd, pnn50) = self.timeView.calculateTimeIndices(with: timestamps)
        
        // Calcolo degli indici di frequenza
        let (LF, HF, LFn, HFn, LF_HF) = self.calculateFreqIndices(with: RR_res)
        
        // Standardizzazione degli indici
        let mean_st = (mean - 886.1335) / 130.6106
        let sdnn_st = (sdnn - 58.0515) / 20.8270
        let rmssd_st = (rmssd - 44.3016) / 20.9321
        let pnn50_st = (pnn50 - 0.1033) / 0.0854
        let LFn_st = (LFn - 0.6112) / 0.1550
        let HFn_st = (HFn - 0.3017) / 0.1359
        let LF_HF_st = (LF_HF - 2.6482) / 1.5755
        print("LFn: \(LFn)")
        print("HFn: \(HFn)")
        print("LF_HF: \(LF_HF)")
        print("LF: \(LF)")
        print("HF: \(HF)")
        
        
        
        // Restituzione degli indici standardizzati
        return (mean_st, sdnn_st, rmssd_st, pnn50_st, LFn_st, HFn_st, LF_HF_st)
    }

        
        
    

    func calculateFreqIndices(with RR_res: [Double]) -> (Double, Double, Double, Double, Double) {
        let fs = 4.0 // Hz
        let N = RR_res.count
        var len_stop = 0
        var HF = 0.0, LF = 0.0, VLF = 0.0

        if N % 2 == 0 {
            len_stop = N / 2 + 1
        } else {
            len_stop = (N + 1) / 2
        }
        
        var Re = [Double](repeating: 0.0, count: len_stop)
        var Im = [Double](repeating: 0.0, count: len_stop)
        
        for k in 0..<len_stop {
            var sumRe = 0.0
            var sumIm = 0.0
            
            for n in 0..<N {
                let angle = 2.0 * Double.pi / Double(N) * Double(k) * Double(n)
                let cosine = cos(angle)
                let sine = sin(angle)
                sumRe += RR_res[n] * cosine
                sumIm += RR_res[n] * sine
            }
            
            Re[k] = sumRe
            Im[k] = sumIm
        }
        
        var PSD = [Double](repeating: 0.0, count: len_stop)
        
        for k in 0..<len_stop {
            let num = pow(Re[k], 2) + pow(Im[k], 2)
            PSD[k] = num / (Double(N) * fs)
        }
        
        if N % 2 == 0 { // pari
            for k in 1..<(len_stop - 1) { // dal secondo al penultimo termine
                PSD[k] = 2 * PSD[k]
            }
        } else { // dispari
            for k in 1..<len_stop { // dal secondo all'ultimo termine
                PSD[k] = 2 * PSD[k]
            }
        }
        
        var deltaf: Double = 0.0
        var freq = [Double](repeating: 0.0, count: len_stop)
        
        if N % 2 == 0 {
            // oppure, se preferisci usare una variabile booleana:
            // let isEven = N % 2 == 0
            deltaf = fs / Double(N)
        } else {
            deltaf = fs / Double(N - 1)
        }

        for i in 1..<len_stop {
            freq[i] = freq[i - 1] + deltaf
        }


        var s = 0
        
        while s < len_stop - 1  && freq[s] < 0.04 {
            let area = (PSD[s] + PSD[s + 1]) * deltaf / 2
            VLF += area
            s += 1
        }

        while s < len_stop - 1  && freq[s] < 0.15 {
            let area = (PSD[s] + PSD[s + 1]) * deltaf / 2
            LF += area
            s += 1
        }

        while s < len_stop - 1  && freq[s] < 0.4 {
            let area = (PSD[s] + PSD[s + 1]) * deltaf / 2
            HF += area
            s += 1
        }

        var rest = 0.0
        
        while s < len_stop - 1  && freq[s] < fs / 2 {
            let area = (PSD[s] + PSD[s + 1]) * deltaf / 2
            rest += area
            s += 1
        }

        let tot_pow = VLF + HF + LF + rest
        let LFn = LF / (tot_pow - VLF)
        let HFn = HF / (tot_pow - VLF)
        let LF_HF = LF / HF

        return (LF, HF, LFn, HFn, LF_HF)
    }
}
