//
//  ContentView.swift
//  Prova1
//
//  Created by Sara Varone on 04/04/24.
//
import SwiftUI
import Photos
import PhotosUI
import AVFoundation
import UIKit
import HealthKit
import HealthKitUI
import Contacts

struct ContentView: View {
    var body: some View {
        TabView{
            HomeView()
                .tabItem{
                    Image(systemName: "house.fill")
                }
            
            SecondScreenView()
                .tabItem{
                    Image(systemName: "person.fill")
                }
        }
    }
    
}
      
#Preview{
        ContentView()
        //.environmentObject(HealthManager())
}

