//
//  FinestreView.swift
//  wemos1.0
//
//  Created by Sara Varone on 04/05/24.
//

import SwiftUI

struct FinestreView: View {
    var body: some View {
    
        NavigationView{
            VStack{
                Text("Here's the 4 graphics, one for each emotion\n")
                    .font(.title)
                    .multilineTextAlignment(.center)
            
                NavigationLink(destination:SadnessView().navigationBarBackButtonHidden(true)){
                    Text("Sadness\n")
                        .font(.headline)
                        .foregroundColor(.blue)
                }
                NavigationLink(destination:AngerView().navigationBarBackButtonHidden(true)){
                    Text("Anger\n")
                        .font(.headline)
                        .foregroundColor(.red)
                         
                }
                NavigationLink(destination:HappinessView().navigationBarBackButtonHidden(true)){
                    Text("Happines\n")
                        .font(.headline)
                        .foregroundColor(.yellow)
                         
                }
                NavigationLink(destination:FearView().navigationBarBackButtonHidden(true)){
                    Text("Fear\n")
                        .font(.headline)
                        .foregroundColor(.purple)
                         
                }
            }
        }
    }
}

#Preview {
    FinestreView()
}
